package controller;

import java.io.IOException;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Moradores;
import model.MoradoresDAO;

@WebServlet("/LController")
public class LController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private MoradoresDAO moradoresDAO;
	
	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("condorec-jpa");
	
	@Override
	public void init() throws ServletException {
		moradoresDAO = new MoradoresDAO(emf);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String operacao = request.getParameter("operacao");
		operacao = operacao.toLowerCase();
		
		switch(operacao) {
			case "logar":
				logarADM(request, response);
				break;
			case "entrar":
				logarMorador(request, response);
				break;
			default:
				System.out.println("Erro! Operação não encontrada.");
				
		}
	}
		
		public void logarADM(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		String login = request.getParameter("login");
		String senha = request.getParameter("senha");
		
		if(login.equals("adm") && senha.equals("123")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/paginaADM.html");
			dispatcher.forward(request, response);
		}
		else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");
			
			dispatcher.forward(request, response);
		}
		
		}
		
		public void logarMorador(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			String login = request.getParameter("login");
			String senha = request.getParameter("senha");
			
			Moradores moradoresBanco = moradoresDAO.procurarMorador(login);
			
			if(moradoresBanco != null) {
				if((moradoresBanco.getSenha()).equals(senha)){
					RequestDispatcher dispatcher = request.getRequestDispatcher("/paginaMorador.html");
					dispatcher.forward(request, response);
				}else {
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");
					dispatcher.forward(request, response);
				}
				
			}else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");
				dispatcher.forward(request, response);
			}
		}

}
