package controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Moradores;
import model.Residuos;
import model.ResiduosDAO;


@WebServlet("/RController")
public class RController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ResiduosDAO residuosDAO;
	
	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("condorec-jpa"); 
	
	@Override
	public void init() throws ServletException {
		residuosDAO = new ResiduosDAO(emf);
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String operacao = request.getParameter("operacao");
		operacao = operacao.toLowerCase();
		
		switch(operacao) {
			case "listar":
				listarResiduos(request, response);
				break;
			case "remover":
				removerResiduos(request, response);
				break;
			case "buscar":
				buscarResiduo(request, response);
				break;
			default:
				System.out.println("Erro! Operação não encontrada!");
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String operacao = request.getParameter("operacao");
		operacao = operacao.toLowerCase();
		
		switch(operacao) {
			case "cadastrar":
				cadastrarResiduos(request, response);
				break;
			case "atualizar":
				atualizarResiduo(request, response);
				break;
			default:
				System.out.println("Erro! Operação não encontrada!");
		}
	}
	
	private void cadastrarResiduos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String login = request.getParameter("login");	
		double qtd = Double.parseDouble(request.getParameter("qtd"));
		String data = request.getParameter("data");
		String material = request.getParameter("material");
		
		boolean inseriu = residuosDAO.cadResiduos(login, qtd, data, material);
		
		request.setAttribute("status", inseriu);
		request.setAttribute("operacao", "cadastrado");
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/status2.jsp");
		dispatcher.forward(request, response);
		
		
	}
	
	private void removerResiduos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		boolean excluiu = residuosDAO.excluirResiduos(id);
		
		request.setAttribute("status", excluiu);
		request.setAttribute("operacao", "removido");
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/status2.jsp");
		dispatcher.forward(request, response);
	}
	
	private void listarResiduos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		List<Residuos> listaResiduos = residuosDAO.listarResiduos();
		
		request.setAttribute("materiaisBanco", listaResiduos);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/ListResiduo.jsp");
		dispatcher.forward(request, response);
	}
	
	private void buscarResiduo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		Residuos residuosBanco = residuosDAO.procurarResiduo(id);
		
		request.setAttribute("residuos", residuosBanco);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/AtualizaResiduo.jsp");
		dispatcher.forward(request, response);
	}
	
	private void atualizarResiduo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String login = request.getParameter("login");	
		double qtd = Double.parseDouble(request.getParameter("qtd"));
		String data = request.getParameter("data");
		String material = request.getParameter("material");
		
		boolean atualizou = residuosDAO.modificarResiduo(login, qtd, data, material);
		
		request.setAttribute("status", atualizou);
		request.setAttribute("operacao", "atualizado");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/status2.jsp");
		dispatcher.forward(request, response);
	}
}