package controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Moradores;
import model.MoradoresDAO;

@WebServlet("/MController")
public class MController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private MoradoresDAO moradoresDAO;
	
	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("condorec-jpa");
	
	@Override
	public void init() throws ServletException {
		moradoresDAO = new MoradoresDAO(emf);
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String operacao = request.getParameter("operacao");
		operacao = operacao.toLowerCase();
		
		switch(operacao) {
			case "remover":
				removerMorador(request, response);
				break;
			case "listar":
				listarMoradores(request, response);
				break;
			case "buscar":
				buscarMorador(request, response);
				break;
			default:
				System.out.println("Erro! Operação não encontrada.");
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String operacao = request.getParameter("operacao");
		operacao = operacao.toLowerCase();
		
		switch(operacao) {
			case "cadastrar":
				cadastrarMorador(request, response);
				break;
			case "atualizar":
				atualizarMorador(request, response);
				break;
			default:
				System.out.println("Erro! Operação não encontrada.");
		}
	}

	private void cadastrarMorador(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String login = request.getParameter("login");
		String nome = request.getParameter("nomeCom");
		String telefone = request.getParameter("telefone");
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");
		int apto = Integer.parseInt(request.getParameter("apto"));
		int bloco = Integer.parseInt(request.getParameter("bloco"));
		
		boolean inseriu = moradoresDAO.cadMorador(login, nome, telefone, email, senha, apto, bloco);
		
		request.setAttribute("status", inseriu);
		request.setAttribute("operacao", "cadastrado");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/status.jsp");
		dispatcher.forward(request, response);
	}
	
	private void removerMorador(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String login = request.getParameter("login");
		
		boolean excluiu = moradoresDAO.excluirMorador(login);
		
		request.setAttribute("status", excluiu);
		request.setAttribute("operacao", "removido");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/status.jsp");
		dispatcher.forward(request, response);
	}
	
	private void listarMoradores(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Moradores> listaMoradores = moradoresDAO.consultarMoradores();
		
		request.setAttribute("moradoresBanco", listaMoradores);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/ListMorador.jsp");
		dispatcher.forward(request, response);
	}
	
	private void buscarMorador(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String login = request.getParameter("login");
		
		Moradores moradoresBanco = moradoresDAO.procurarMorador(login);
		
		request.setAttribute("moradores", moradoresBanco);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/AtualizaMorador.jsp");
		dispatcher.forward(request, response);
	}
	
	private void atualizarMorador(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String login = request.getParameter("login");
		String nome = request.getParameter("nomeCom");
		String telefone = request.getParameter("telefone");
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");
		int apto = Integer.parseInt(request.getParameter("apto"));
		int bloco = Integer.parseInt(request.getParameter("bloco"));
		
		boolean atualizou = moradoresDAO.modificarMorador(login, nome, telefone, email, senha, apto, bloco);
		
		request.setAttribute("status", atualizou);
		request.setAttribute("operacao", "atualizado");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/status.jsp");
		dispatcher.forward(request, response);
	}
}