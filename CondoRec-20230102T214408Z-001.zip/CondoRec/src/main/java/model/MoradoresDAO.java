package model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

public class MoradoresDAO {
	private EntityManagerFactory emf;
	
	public MoradoresDAO(EntityManagerFactory emf) {
		super();
		this.emf = emf;
	}

	public boolean cadMorador(String login, String nome, String telefone, String email, String senha, int apto, int bloco) {
		EntityManager em = emf.createEntityManager();
		
		try {
			Moradores moradores = new Moradores(login, nome, telefone, email, senha, apto, bloco);
			em.getTransaction().begin();
			em.persist(moradores);
			em.getTransaction().commit();
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			em.close();
		}
	}
	
	public boolean excluirMorador(String login) {
		EntityManager em = emf.createEntityManager();
		
		try {
			Moradores moradores = em.find(Moradores.class, login);
			em.getTransaction().begin();
			em.remove(moradores);
			em.getTransaction().commit();
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			em.close();
		}
	}
	
	public List<Moradores> consultarMoradores() {	
		List<Moradores> listaMoradores = new ArrayList<>();
		EntityManager em = emf.createEntityManager();
		
		try {
			listaMoradores = em.createQuery("from " + Moradores.class.getName()).getResultList();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			em.close();
		}
		return listaMoradores;
	}
	
	public Moradores procurarMorador(String login) {
		EntityManager em = emf.createEntityManager();
		Moradores moradores = null;
		
		try {
			moradores = em.find(Moradores.class, login);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			em.close();
		}
		return moradores;
	}
	
	public boolean modificarMorador(String login, String nome, String telefone, String email, String senha, int apto, int bloco) {	
		EntityManager em = emf.createEntityManager();
		
		try {
			Moradores moradores = new Moradores(login, nome, telefone, email, senha, apto, bloco);
			em.getTransaction().begin();
			em.merge(moradores);
			em.getTransaction().commit();
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			em.close();
		}
	}
	
}
