package model;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

public class ResiduosDAO {
	private EntityManagerFactory emf;
	
	public ResiduosDAO(EntityManagerFactory emf) {
		super();
		this.emf = emf;
	}

	public boolean cadResiduos(String login, double qtd, String data, String material) {
		EntityManager em = emf.createEntityManager();
		
		try {
			Residuos residuos = new Residuos(login, qtd, data, material);
			em.getTransaction().begin();
			em.persist(residuos);
			em.getTransaction().commit();
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			em.close();
		}
	}
	
	public List<Residuos> listarResiduos() {	
		List<Residuos> listaResiduos = new ArrayList<>();
		EntityManager em = emf.createEntityManager();
		
		try {
			listaResiduos = em.createQuery("from " + Residuos.class.getName()).getResultList();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			em.close();
		}
		return listaResiduos;
	}
	
	
	public boolean excluirResiduos(int id) {
		EntityManager em = emf.createEntityManager();
		
		try {
			
			Residuos residuos = em.find(Residuos.class, id);
			em.getTransaction().begin();
			em.remove(residuos);
			em.getTransaction().commit();
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			em.close();
		}
		
	}
	
	public Residuos procurarResiduo(int id) {
		EntityManager em = emf.createEntityManager();
		Residuos residuos = null;
		
		try {
			residuos = em.find(Residuos.class, id);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			em.close();
		}
		return residuos;
	}
	
	public boolean modificarResiduo(String login, double qtd, String data, String material) {	
		EntityManager em = emf.createEntityManager();
		
		try {
			Residuos residuos = new Residuos(login, qtd, data, material);
			em.getTransaction().begin();
			em.merge(residuos);
			em.getTransaction().commit();
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			em.close();
		}
	}
	
}
