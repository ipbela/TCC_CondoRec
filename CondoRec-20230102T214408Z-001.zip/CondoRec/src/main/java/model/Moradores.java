package model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Moradores {
	@Id
	private String login;
	private String nome;
	private String telefone;
	private String email;
	private String senha;
	private int apto;
	private int bloco;
	
	public Moradores() {
		super();
	}

	public Moradores(String login, String nome, String telefone, String email, String senha, int apto, int bloco) {
		super();
		this.login = login;
		this.nome = nome;
		this.telefone = telefone;
		this.email = email;
		this.senha = senha;
		this.apto = apto;
		this.bloco = bloco;
	}

	public Moradores(String nome, String telefone, String email, String senha, int apto, int bloco) {
		super();
		this.nome = nome;
		this.telefone = telefone;
		this.email = email;
		this.senha = senha;
		this.apto = apto;
		this.bloco = bloco;
	}
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public int getApto() {
		return apto;
	}

	public void setApto(int apto) {
		this.apto = apto;
	}

	public int getBloco() {
		return bloco;
	}

	public void setBloco(int bloco) {
		this.bloco = bloco;
	}
}
