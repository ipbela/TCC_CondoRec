package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Residuos {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String login;
	private double qtd;
	private String data;
	private String material;
	
	public Residuos() {
		super();
		
	}

	public Residuos(String login, double qtd, String data, String material) {
		super();
		this.login = login;
		this.qtd = qtd;
		this.data = data;
		this.material = material;
	}

	public Residuos(int id, String login, double qtd, String data, String material) {
		super();
		this.id = id;
		this.login = login;
		this.qtd = qtd;
		this.data = data;
		this.material = material;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public double getQtd() {
		return qtd;
	}
	public void setQtd(double qtd) {
		this.qtd = qtd;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	
	
}
